import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '../supabaseClient';

const UserContext = createContext();

export function UserProvider({ children }) {
    const [user, setUser] = useState(null);
    const [profile, setProfile] = useState(null);
    const [academy, setAcademy] = useState(null);
    const [loading, setLoading] = useState(true);

    const fetchProfile = async () => {
        try {
            const { data: { user: authUser } } = await supabase.auth.getUser();
            if (authUser) {
                setUser(authUser);

                // Fetch Profile
                const { data: profileData, error: profileError } = await supabase
                    .from('profiles')
                    .select('*')
                    .eq('id', authUser.id)
                    .single();

                if (profileError && profileError.code !== 'PGRST116') {
                    console.error("Error fetching profile:", profileError);
                }

                if (profileData) {
                    setProfile(profileData);

                    // Fetch Academy if linked
                    if (profileData.academy_id) {
                        const { data: academyData } = await supabase
                            .from('academies')
                            .select('*')
                            .eq('id', profileData.academy_id)
                            .single();
                        setAcademy(academyData);
                    }
                }
            } else {
                setUser(null);
                setProfile(null);
                setAcademy(null);
            }
        } catch (error) {
            console.error("UserContext Error:", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchProfile();

        // Listen for auth changes
        const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
            if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
                await fetchProfile();
            } else if (event === 'SIGNED_OUT') {
                setUser(null);
                setProfile(null);
                setAcademy(null);
            }
        });

        return () => {
            subscription?.unsubscribe();
        };
    }, []);

    const branding = {
        name: academy?.name || 'Wild Robot',
        logo_url: academy?.logo_url,
        initial: academy?.name ? academy.name.charAt(0).toUpperCase() : 'W',
        color: 'emerald' // Default brand color
    };

    return (
        <UserContext.Provider value={{
            user,
            profile,
            academy,
            branding,
            loading,
            refreshProfile: fetchProfile
        }}>
            {children}
        </UserContext.Provider>
    );
}

export function useUser() {
    return useContext(UserContext);
}
