import React, { useEffect, useState } from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { supabase } from '../supabaseClient';
import { Loader2 } from 'lucide-react';

const ProtectedRoute = ({ allowedRoles = [], allowSetup = false }) => {
    const location = useLocation();
    const [loading, setLoading] = useState(true);
    const [isAuthorized, setIsAuthorized] = useState(false);
    const [userRole, setUserRole] = useState(null);
    const [needsSetup, setNeedsSetup] = useState(false);

    useEffect(() => {
        const checkAccess = async () => {
            const { data: { session } } = await supabase.auth.getSession();

            if (!session) {
                setLoading(false);
                return;
            }

            // Fetch Profile AND Academy Status
            let { data: profile } = await supabase
                .from('profiles')
                .select('*, academies(setup_completed)')
                .eq('id', session.user.id)
                .single();

            // Fallback to metadata if needed
            const role = profile?.role || session.user.user_metadata?.role;
            setUserRole(role);

            // Check Onboarding Status (The Traffic Cop 👮‍♂️)
            if (role === 'owner') {
                const isSetupComplete = profile?.academies?.setup_completed;

                // If owner has NOT completed setup, and we are NOT allowing setup access (i.e. on a normal page) -> BLOCK
                if (!isSetupComplete && !allowSetup) {
                    setNeedsSetup(true);
                    setLoading(false);
                    return;
                }
            }

            // Check Role Authorization
            if (allowedRoles.length > 0 && !allowedRoles.includes(role)) {
                setIsAuthorized(false);
            } else {
                setIsAuthorized(true);
            }
            setLoading(false);
        };

        checkAccess();
    }, [allowedRoles, allowSetup]);

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-slate-50">
                <Loader2 className="animate-spin text-emerald-600 w-10 h-10" />
            </div>
        );
    }

    // 1. Not Logged In -> Login
    if (!userRole) {
        return <Navigate to="/login" state={{ from: location }} replace />;
    }

    // 2. Needs Setup -> Force Redirect to /setup
    // (This catches owners trying to access dashboard before wizard)
    if (needsSetup) {
        return <Navigate to="/setup" replace />;
    }

    // 3. Logged In but Wrong Role -> Redirect to their correct home
    if (!isAuthorized) {
        if (userRole === 'owner') return <Navigate to="/owner/dashboard" replace />;
        if (['coach', 'head_coach'].includes(userRole)) return <Navigate to="/coach/home" replace />;
        if (userRole === 'athlete') return <Navigate to="/athlete" replace />;
        return <Navigate to="/" replace />; // Fallback
    }

    // 4. Authorized -> Render Content
    return <Outlet />;
};

export default ProtectedRoute;
