import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';

// ----------------------------------------------------------------------
// 1. Imports
// ----------------------------------------------------------------------

// Auth
import Login from './pages/auth/Login';
import Signup from './pages/auth/Signup';
import MobileLogin from './pages/auth/MobileLogin';
import Pricing from './pages/auth/Pricing';
import FakeCheckout from './pages/auth/FakeCheckout';

// Layouts
import OwnerLayout from './layouts/OwnerLayout';
import AthleteLayout from './layouts/StudentLayout';

// Owner Pages
import OwnerDashboard from './pages/owner/OwnerDashboard';
import AcademySetup from './pages/owner/AcademySetup';

// Athlete Pages
import AthleteHome from './pages/Athlete/AthleteHome';
import Achievements from './pages/Athlete/Achievements';

// Lazy Loading
const AthleteBilling = React.lazy(() => import('./pages/Athlete/Billing'));
const AthleteSettings = React.lazy(() => import('./pages/Athlete/Settings'));

// Shared
import Landing from './pages/Landing';
import NotFound from './pages/NotFound';
import SecurityCheckpointPage from './components/SecurityCheckpoint';

// Components
import ErrorBoundary from './components/ErrorBoundary';
import CommandPalette from './components/CommandPalette';
import AuthGuard from './components/AuthGuard';
import ProtectedRoute from './components/ProtectedRoute';

function App() {
    return (
        <ErrorBoundary>
            <BrowserRouter>
                <CommandPalette />
                <Routes>
                    {/* Public Routes */}
                    <Route path="/" element={<Landing />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/signup" element={<Signup />} />
                    <Route path="/athlete/login" element={<Navigate to="/login" replace />} />
                    <Route path="/pricing" element={<Pricing />} />
                    <Route path="/checkout" element={<FakeCheckout />} />
                    <Route path="/security-checkpoint" element={<SecurityCheckpointPage />} />

                    {/* -----------------------------------------------------------------
                        🛡️ OWNER SETUP ZONE (The Gateway)
                        Must be logged in as owner, but allows incomplete setup.
                        The "allowSetup={true}" prop prevents the infinite redirect loop.
                    ----------------------------------------------------------------- */}
                    <Route element={<ProtectedRoute allowedRoles={['owner']} allowSetup={true} />}>
                        <Route path="/setup" element={<AcademySetup />} />
                    </Route>

                    {/* -----------------------------------------------------------------
                        🏰 OWNER KINGDOM (Protected & Setup Required)
                        Standard protection. If setup is incomplete, Guard redirects to /setup.
                    ----------------------------------------------------------------- */}
                    <Route path="/owner" element={<ProtectedRoute allowedRoles={['owner']} />}>
                        <Route element={<OwnerLayout />}>
                            <Route index element={<Navigate to="/owner/dashboard" replace />} />
                            <Route path="dashboard" element={<OwnerDashboard />} />

                            {/* Future Modules */}
                            <Route path="academy" element={<div className="p-10 font-bold text-slate-400 text-center">Academy Management</div>} />
                            <Route path="staff" element={<div className="p-10 font-bold text-slate-400 text-center">Staff Portal</div>} />
                            <Route path="finance" element={<div className="p-10 font-bold text-slate-400 text-center">Treasury & Finance</div>} />
                            <Route path="athletes" element={<div className="p-10 font-bold text-slate-400 text-center">Athlete Roster</div>} />
                            <Route path="schedule" element={<div className="p-10 font-bold text-slate-400 text-center">Class Schedule</div>} />
                            <Route path="settings" element={<div className="p-10 font-bold text-slate-400 text-center">System Settings</div>} />
                        </Route>
                    </Route>

                    {/* COACH ZONE (Redirect to Owner for now) */}
                    <Route path="/coach/*" element={<Navigate to="/owner/dashboard" replace />} />

                    {/* 🔄 Legacy Redirects */}
                    <Route path="/student/*" element={<Navigate to="/athlete" replace />} />

                    {/* 🏅 ATHLETE DASHBOARD (SECURED 🛡️) */}
                    <Route path="/athlete" element={
                        <AuthGuard>
                            <AthleteLayout />
                        </AuthGuard>
                    }>
                        <Route index element={<AthleteHome />} />
                        <Route path="achievements" element={<Achievements />} />

                        <Route path="billing" element={
                            <React.Suspense fallback={<div>Loading...</div>}>
                                <AthleteBilling />
                            </React.Suspense>
                        } />

                        <Route path="settings" element={
                            <React.Suspense fallback={<div>Loading...</div>}>
                                <AthleteSettings />
                            </React.Suspense>
                        } />
                    </Route>

                    <Route path="*" element={<NotFound />} />
                </Routes>
            </BrowserRouter>
        </ErrorBoundary>
    );
}

export default App;